// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("wasm32 build"); }
int main(){
  announce();
  return lionss_run_workload("wasm32-build");
}
